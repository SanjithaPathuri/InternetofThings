#ifndef N135_H_
#define N135_H_

#define WL_FW_VER_LENGTH 6
#define NO_SOCKET_AVAIL     255

#endif /* N135_H_ */
