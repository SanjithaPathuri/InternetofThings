# corelibs-galileo
